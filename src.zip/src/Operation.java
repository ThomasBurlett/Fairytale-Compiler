public class Operation
{
    public int opType;
    public String jump;	// Opposite of the comparison
}