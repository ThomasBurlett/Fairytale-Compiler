public class Operation
{
    public int opType;
}